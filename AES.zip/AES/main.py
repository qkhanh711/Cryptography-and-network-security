class AES:
    def __init__(self, key):
        self.key = key
        pass

    def add(self, block):
        pass
    
    def sub(self, block):
        pass

    def shift(self, block):
        pass

    def mix(self, block):
        pass

    def Block(self, block):
        pass

    def encrypt(self, plain):
        pass

    def decrypt(self, cipher):
        pass

    def key_expansion(self, key):
        pass